<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "Robot_Base";
$conn = new mysqli($host, $username, $password, $dbname);

if($conn->connect_error){
	echo " connection Failed! ".$conn->connect_error;
}
    else{ 
		 echo " Connected successfully... ";
 }
?>